// src/typings.d.ts
declare module 'qrcode';

/// <reference types="jquery" />
/// <reference types="datatables.net" />

declare module 'html2pdf.js';
